<p><?php _e( 'Help improve Jobify by submitting a rating and helping to translate the theme to as many languages as possible!', 'jobify' ); ?></p>

<p>
	<a href="https://astoundify.com/go/rate-jobify/" class="button-secondary"><?php _e( 'Leave a Positive Review', 'jobify' ); ?></a>
	<a href="http://bit.ly/translate-jobify" class="button-secondary"><?php _e( 'Contribute Your Translation', 'jobify' ); ?></a>
</p>
