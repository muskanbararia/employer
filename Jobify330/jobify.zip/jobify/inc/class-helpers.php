<?php
/**
 * Some helpful stuff. These are all access statically.
 *
 * @since 3.0.0
 * @package Jobify
 * @category Utilities
 */
class Jobify_Helpers {


}
