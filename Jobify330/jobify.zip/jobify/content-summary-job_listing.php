<?php
/**
 * Template for the [job_summary] shortcode.
 *
 * @package Jobify
 * @category Template
 * @since 3.0.0
 */

locate_template( array( 'content-single-job-featured.php' ), true, false );
