<script id="tmpl-infoBubble" type="text/template">
    <# if ( typeof( data.title ) != 'undefined') { #>
        <a href="{{{ data.href }}}">{{{ data.title }}}</a>
    <# } #>
</script>
